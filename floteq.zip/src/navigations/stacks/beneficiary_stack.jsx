import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Preview from '@/screens/app/preview';
import AddBeneficiary from '@/screens/app/beneficiary/AddBeneficiary';
import PaymentTypes from '@/screens/app/preview/paymenttypes';
import BankDetails from '@/screens/app/preview/bankdetails';
import SuccessTransaction from '@/screens/app/preview/successtransaction';
import VoltHtmlWebsiteView from '@/screens/app/preview/volthtmlwebsiteview';

const Stack = createStackNavigator();

const BeneficiaryStack = () => {
  return (
    <Stack.Navigator
      initialRouteName='SearchBeneficiaryScreen'
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name='PreviewScreen' component={Preview} />
    </Stack.Navigator>
  );
};

export default BeneficiaryStack;
