import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Login from '@/screens/auth/login';
import AppBottomTab from '../tabs/bottom_tab';


const Stack = createStackNavigator();

const AuthStack = () => {
  return (
    <Stack.Navigator initialRouteName='LoginScreen' screenOptions={{ headerShown: false }}>
      <Stack.Screen name='LoginScreen' component={Login} />
      <Stack.Screen name='AppBottomTab' component={AppBottomTab} />
    </Stack.Navigator>
  );
};

export default AuthStack;
