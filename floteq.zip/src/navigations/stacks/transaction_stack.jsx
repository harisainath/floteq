import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import TransactionList from '@/screens/app/transaction/TransactionList';
import TransactionDetails from '@/screens/app/transaction/TransactionDetails';
import TransferEnterAmount from '@/screens/app/transaction/TransferEnterAmount';
import Preview from '@/screens/app/preview';

const Stack = createStackNavigator();

const TransactionStack = () => {
  return (
    <Stack.Navigator
      initialRouteName='AlertsList'
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name='AlertsList' component={TransactionList} />
    </Stack.Navigator>
  );
};

export default TransactionStack;
