import { View, Text, StyleSheet, Image } from 'react-native';
import React, { useEffect, useState } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { ColorSheet } from '@/utils/ColorSheet';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import { RFValue } from 'react-native-responsive-fontsize';
import Home from '@/assets/icons/bottom_tab/Home.svg';
import Swap from '@/assets/icons/bottom_tab/Swap.svg';
import UserGroup from '@/assets/icons/bottom_tab/UserGroup.svg';
import TransactionStack from '../stacks/transaction_stack';
import HomeScreen from '@/screens/app/home';
import Swap90 from '@/assets/icons/bottom_tab/Swap90.svg';
import BeneficiaryStack from '../stacks/beneficiary_stack';
import HomeStack from '../stacks/profile_stack';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

const AppBottomTab = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        // When open the Keyboard that time Avoid the TabBar
        tabBarHideOnKeyboard: true,
        headerShown: false,
        tabBarActiveTintColor: ColorSheet.SecondaryText,
        tabBarInactiveTintColor: ColorSheet.InactiveIcon,
        tabBarStyle: {
          height: hp(7),
          borderTopWidth: 0,
          paddingRight: wp(3),
          backgroundColor: ColorSheet.White,
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          position: 'absolute',
        },

        tabBarShowLabel: false,
      }}
    >
      <Tab.Screen
        name='HomeStack'
        component={HomeStack}
        options={() => ({
          tabBarIcon: ({ color, focused }) => (
            <View
              style={[
                styles.iconView,
                focused && {
                  backgroundColor: ColorSheet.StatusBarBg,
                },
              ]}
            >
              <Home fill={color} />
              {focused && (
                <Text
                  style={[
                    styles.labelText,
                    {
                      color: color,
                    },
                  ]}
                >
                  Dashboard
                </Text>
              )}
            </View>
          ),
        })}
      />
      <Tab.Screen
        name='TransactionStack'
        component={TransactionStack}
        options={() => ({
          tabBarIcon: ({ color, focused }) => (
            <View
              style={[
                styles.iconView,
                focused && {
                  backgroundColor: ColorSheet.StatusBarBg,
                },
              ]}
            >
              <MaterialCommunityIcons name='alert' size={20} />

              {focused && (
                <Text
                  style={[
                    styles.labelText,
                    {
                      color: color,
                    },
                  ]}
                >
                  Alert Center
                </Text>
              )}
            </View>
          ),
        })}
      />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  iconView: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    paddingHorizontal: wp(3),
    paddingVertical: hp(1.2),
    borderRadius: 50,
  },
  labelText: {
    fontSize: RFValue(11),
    fontWeight: '400',
    marginLeft: hp(0.2),
  },
  profileImage: {
    width: hp(6),
    height: hp(6),
    resizeMode: 'cover',
    borderRadius: 50,
    borderWidth: 1.5,
  },
  transactionsIcon: {
    marginLeft: wp(0.5),
  },
});

export default AppBottomTab;
