import { Image, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import PropTypes from 'prop-types';
import { styles } from './styles';
import { ColorSheet } from '@/utils/ColorSheet';

const TransferWelcomeDashboardComponent = (props) => {
  const { style, imageSource, title, name, onPress, onPressProfile } = props;

  return (
    <View style={[styles.root, style]}>
      {/* Image */}
      <View style={styles.imageNameContainer}>
        {/* <TouchableOpacity onPress={onPressProfile}>
          <Image source={imageSource} style={styles.image} />
        </TouchableOpacity> */}

        <View style={styles.NameContainer}>
          {/* Welcome Title */}
          <Image source={require('@/assets/images/logo_icon.png')} style={{width:60,height:60}} resizeMode='contain' />
          <Text style={styles.welcomeText}> {title} </Text>

          <TouchableOpacity style={styles.iconContainer} onPress={onPress} activeOpacity={0.6}>
            <MaterialIcons name='location-pin' size={40} color={ColorSheet.PrimaryButton} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Icon */}

    </View>
  );
};

// Define prop types
TransferWelcomeDashboardComponent.propTypes = {
  style: PropTypes.object,
  onPress: PropTypes.func,
  title: PropTypes.string,
  name: PropTypes.string,
};

// Define default props
TransferWelcomeDashboardComponent.defaultProps = {
  style: {},
  onPress: null,
  title: '',
  name: '',
};

export default TransferWelcomeDashboardComponent;
