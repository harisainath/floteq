import { ColorSheet } from '@/utils/ColorSheet';
import { Platform, StyleSheet } from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

// const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

export const styles = StyleSheet.create({
  placeholderImageStyle: {
    width: wp(12),
    height: wp(12),
    borderRadius: wp(6),
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: {
    fontSize: RFValue(18),
    color: ColorSheet.Text0,
    fontWeight: 'bold',
  },
  root: {
    width: '93%',
    marginTop: Platform.OS == 'android' ? hp(7) : hp(9),
    flexDirection: 'row',
    // backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  imageNameContainer: {
    flexDirection: 'row',
    // backgroundColor: 'green'
  },
  NameContainer: {
    justifyContent: 'space-between',
    alignItems:'center',
    width: wp(95),
    flexDirection:'row',
  },
  image: {
    width: wp(14),
    height: wp(14),
    resizeMode: 'cover',
    borderRadius: wp(7),
  },
  welcomeText: {
    fontSize: RFValue(21),
    fontWeight: '700',
    color: ColorSheet.PrimaryButton,
    // marginLeft: wp(2),
  },
  nameText: {
    paddingTop: hp(0.3),
    fontSize: RFValue(12),
    fontWeight: '500',
    color: ColorSheet.Secondary,
  },
  iconContainer: {
    
    alignItems: 'center',
    justifyContent: 'center',
    // marginLeft: wp(2),
  },
});
