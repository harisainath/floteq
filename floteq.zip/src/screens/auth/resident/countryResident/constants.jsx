export const Constants = {
  FIRST_TXT: 'Tell us where you’re from',
  SECOND_TXT: 'What’s your country of residendence',

  NON_US_RESIDENT: 'Non-US resident',
  US_RESIDENT: 'US resident',

  URL_NAME: 'Learn more about why we are asking for this information',

  CONTINUE: 'Continue',
};
