export const Constants = {
  SUB_TITLE_01: 'Upload your proof of',
  SUB_TITLE_02: 'Address document',

  SELECT_TYPE: 'Select document type',
  CLICK_UPLOAD: 'click To upload',
  JPG_PDF: 'Jpg, pdf or Png (max. 50mb)',

  SELECT_TYPE_REQUIRE: 'Please select document type',

  IMAGE_REQUIRE: 'Please Upload Image',

  WE_DO_NOT_ACCEPT: 'We don’t accept',

  Header: ['Screenshots', 'Reciept for purchases', 'Medical Bills'],

  CONTINUE: 'Continue',
};
