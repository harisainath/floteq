export const Constants = {
  FIRST_TXT: 'Select type and issuing country of your',
  SECOND_TXT: 'identity document',

  ISSUING_COUNTRY_LABEL: 'Issuing country',
  UNITED_KINGDOM: 'United Kingdom',

  COUNTRY_REQUIRE: 'Please select country',
  SELECT_REQUIRE: 'Select document type',

  VERIFICATION_TYPE_LABEL: 'Verification Type',

  VerificationType: ['Driver’s Licences', 'Id Card', 'Residence Permit', 'Passport'],

  CONTINUE: 'Continue',
};
