import {
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, { useEffect, useState } from 'react';
import TextInputField from '@/components/input/TextInput';
import PrimaryButton from '@/components/buttons/primaryButton';
import { styles } from './styles';
import { Constants } from './constants';
import { ErrorFlash } from '@/utils/flashMessage';
import postRequest from '@/components/NetworkRequest/postRequest';
import { DefaultConstants } from '@/utils/Constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ColorSheet } from '@/utils/ColorSheet';
import { heightPercentageToDP, widthPercentageToDP } from 'react-native-responsive-screen';
import axios from 'axios';

const Login = ({ navigation }) => {
  const [loading, setloading] = useState(false);

  const [formData, setFormData] = useState({
    email: 'appuser@flotequsa.com',
    emailError: '',
    digitCode: 'UDB1cjVjMHJFIQ==',
    digitCodeError: '',
  });

  const onPressSubmit = async () => {
    console.log(formData.email);
    
      if (formData.email == '' || formData.email==null) {
        ErrorFlash(Constants.Email_Id_Required);
      } else if (formData.digitCode == '' || formData.digitCode==null) {
        ErrorFlash(Constants.Pin_Required);
      } else {
        setloading(true)
        await axios.post(DefaultConstants.BASE_URL+'api/auth/login',{
          "email":formData.email,
          "password": formData.digitCode
        },{}).then(resp=>{
            axios.get(DefaultConstants.BASE_URL+'api/user',{
              headers:{
                "X-Requested-With":'AppUser',
                "Authorization":'Bearer '+resp.data.token
              }
            }).then(response=>{
              setAsyncData('UserID', JSON.stringify(response.data.UserID))
              setAsyncData('Email', response.data.Email)
              setAsyncData('api_token', response.data.api_token)
              navigation.navigate('AppBottomTab');
            }).err(error=>{
              ErrorFlash(error.response.data)
            })
        }).catch(err=>{
          ErrorFlash(err.response.data);
        })
        // }
        // else {
        //   ErrorFlash(loginresp[1])
        // }
        setloading(false)
      }
  };
  const setAsyncData = async (key, value) => {
    await AsyncStorage.setItem(key, value)
  }
  const getData = async () => {
    setFormData({ ...formData, email: await AsyncStorage.getItem('Email') });
  }

  useEffect(() => {
    getData()
  }, [])
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle='light-content' backgroundColor={ColorSheet.PrimaryButton} translucent />

      <ScrollView
        contentContainerStyle={styles.scroll_container}
        bounces={false}
        showsVerticalScrollIndicator={false}
      >
        {/* <Image
          source={require('@/assets/images/CreateAccountBG/Create_an_account.png')}
          style={styles.backgroundImage}
        /> */}

        {/* Logo */}
        <View style={styles.logo_container}>
          <Image source={require('@/assets/images/logo.jpeg')} style={{width:widthPercentageToDP(50),height:heightPercentageToDP(18)}} resizeMode='contain'/>
        </View>

        {/* Main Container */}
        <View style={styles.main_container}>
          {/* Header Title */}
          
          <Text style={styles.subTitleText}>{Constants.LOGIN_TEXT}</Text>

          <TextInputField
            value={formData.email}
            onChangeText={(text) => setFormData({ ...formData, email: text })}
            style={styles.email_Field}
            placeholder={Constants.ENTER_EMAIL_TEXT}
          />

          <TextInputField
            value={formData.digitCode}
            onChangeText={(text) => setFormData({ ...formData, digitCode: text })}
            secureTextEntry
            style={styles.password_Field}
            placeholder={Constants.ENTER_PIN_TEXT}
            keyboardType={'default'}
          />

          

          {/* Sign Up Button */}
          <PrimaryButton
            onPress={onPressSubmit}
            style={styles.buttonStyle}
            title={Constants.LOGIN_BUTTON_TEXT}
            loading={loading}
          />

          
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default Login;
