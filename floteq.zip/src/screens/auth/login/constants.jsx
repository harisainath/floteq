export const Constants = {
  WELCOME_TEXT: 'Welcome Back',
  LOGIN_TEXT: 'Please Login to access your account',
  ENTER_EMAIL_TEXT: 'Enter Your Username',
  ENTER_PIN_TEXT: 'Enter Password',
  REMEMBER_ME_TEXT: 'Remember Me',
  FORGOT_PIN_TEXT: 'Forgot PIN?',
  LOGIN_BUTTON_TEXT: 'Login',
  DONT_HAVE_ACCOUNT_TEXT: 'Don’t have an account?',
  REGISTER_TEXT: 'Register',

  Email_Id_Required: 'Username is required',
  Pin_Required: 'Password is required',
};
