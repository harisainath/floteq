import {
    Image,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StatusBar,
    Text,
    View,
} from 'react-native';
import React, { useEffect, useState } from 'react';
import { styles } from './styles';


const SuccessTransaction = ({ navigation, route }) => {
    
    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS == 'ios' ? 'padding' : 'height'}
        >
            {/* StatusBar */}
            <StatusBar barStyle='light-content' backgroundColor={'transparent'} translucent={true} />

           
        </KeyboardAvoidingView>
    );
};

export default SuccessTransaction;