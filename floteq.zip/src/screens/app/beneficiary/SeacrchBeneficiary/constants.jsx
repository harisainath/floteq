export const Constants = {
  HEADER_TITLE: 'Beneficiary',
  SEARCH: 'Search by Beneficiary',
};
