export const Constants = {
  HEADER_TITLE: 'Select Beneficiary',
  BANK_ACC: 'Bank Account',
  UPI: 'UPI',
};
