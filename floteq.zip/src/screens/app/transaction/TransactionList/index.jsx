import {
  ActivityIndicator,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  TouchableOpacity,
  View,
  Text,
  ScrollView,
} from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import { styles } from './styles';
import BackTitleAddComponent from '@/components/BackTitleAdd';
import { Constants } from './constants';
import TransactionListShowData from '@/components/transaction/transactionListShowData';
import getRequest from '@/components/NetworkRequest/getRequest';
import { DefaultConstants } from '@/utils/Constants';
import { ErrorFlash } from '@/utils/flashMessage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ColorSheet } from '@/utils/ColorSheet';
import { FontAwesome5, Foundation, MaterialCommunityIcons } from '@expo/vector-icons';
import TransferWelcomeDashboardComponent from '@/components/transaction/transferWelcomeDashboard';
import Spinner from 'react-native-loading-spinner-overlay';
import axios from 'axios';
import SelectDropdown from 'react-native-select-dropdown';
import PrimaryButton from '@/components/buttons/primaryButton';
import { widthPercentageToDP } from 'react-native-responsive-screen';
import SecondaryButton from '@/components/buttons/secondaryButton';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Modal from 'react-native-modal';
import { DateTimePickerAndroid } from '@react-native-community/datetimepicker';

const TransactionList = ({ navigation }) => {
  const [temperaturealertsData, settemperaturealertsData] = useState([])
  const [alertType, setalertType] = useState("Temperature Alert")
  const [homeoverlay, sethomeoverlay] = useState(false);
  const [fromdate, setFromDate] = useState(new Date());
  const [fromtime, setfromtime] = useState(new Date());
  const [todate, setToDate] = useState(new Date());
  const [totime, settotime] = useState(new Date());


  const [loading, setLoading] = useState(false);

  const setDates = async () => {
    var currentdate = new Date();
    if (currentdate.getHours() >= 6) {
      setFromDate(new Date())
      setToDate(new Date(currentdate.getTime() + 86400000))
      setfromtime(new Date(currentdate.setHours(6, 0, 0)))
      settotime(new Date(new Date(currentdate.getTime() + 86400000).setHours(6, 0, 0)))
    }
    else {
      setFromDate(new Date(currentdate.getTime() - 86400000))
      setToDate(new Date())
      setfromtime(new Date(new Date(currentdate.getTime() + 86400000).setHours(6, 0, 0)))
      settotime(new Date(currentdate.setHours(6, 0, 0)))
    }
  }


  const alerts = async () => {
    setLoading(true)
    const api_token = await AsyncStorage.getItem('api_token');
    var alert = 1;
    if (alertType == "Temperature Alert")
      alert = 1;
    else
      if (alertType == "Pressure Alert")
        alert = 2;
      else
        if (alertType == "After Hours")
          alert = 3;
        else
          if (alertType == "Cleaning Detected")
            alert = 4;
          
    await axios.get(DefaultConstants.BASE_URL+"api/alert-center-data?alertType=" + alert + "&fromdate="+ fromdate.getFullYear() + "-" + ("0" + (fromdate.getMonth() + 1)).slice(-2) + "-" + fromdate.getDate() + "T" + fromtime.getHours() + "%3A" + fromtime.getMinutes() + ":" + fromtime.getSeconds()+"&todate="+ todate.getFullYear() + "-" + ("0" + (todate.getMonth() + 1)).slice(-2) + "-" + todate.getDate() + "T" + totime.getHours() + "%3A" + totime.getMinutes() + ":" + totime.getSeconds()+"&page=1", {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
        "Accept": "application/json"
      }
    }).then(resp => {
      console.log("temp data" + JSON.stringify(resp.data));
      settemperaturealertsData(resp.data.data)
      setLoading(false)
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })
  }

  const onChangeFromdate = (event, selectedDate) => {
    const currentDate = selectedDate;
    setFromDate(currentDate)
  };
  const onChangeFromTime = (event, selectedDate) => {
    const currentDate = selectedDate;
    setfromtime(currentDate)
  };

  const onChangeTodate = (event, selectedDate) => {
    const currentDate = selectedDate;
    setToDate(currentDate)
  };
  const onChangeTotime = (event, selectedDate) => {
    const currentDate = selectedDate;
    settotime(currentDate)
  };

  const fromDateShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeFromdate,
      is24Hour: true,
      mode: 'date'
    });
  }
  const fromTimeShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeFromTime,
      is24Hour: true,
      mode: 'time'
    });
  }

  const toDateShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeTodate,
      is24Hour: true,
      mode: 'date'
    });
  }
  const toTimeShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeTotime,
      is24Hour: true,
      mode: 'time'
    });
  }


  useEffect(() => {
    alerts()
    setDates()
  }, [])
  const devices = [
    "Temperature Alert",
    "Pressure Alert",
    "After Hours",
    "Cleaning Detected"
  ]
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS == 'ios' ? 'padding' : 'height'}
    >
      {loading &&
        <Spinner
          visible={loading}
          textContent={'Loading...'}
          textStyle={{ color: '#FFF' }}
        />
      }
      {!loading &&
        <Modal isVisible={homeoverlay}>
          <View style={{ flex: 0.15, backgroundColor: ColorSheet.White, padding: 10, justifyContent: 'center', alignItems: 'center' }}>
            <SelectDropdown
              data={devices}
              onSelect={(selectedItem, index) => {
                setalertType(selectedItem);
              }}
              renderButton={(selectedItem, isOpened) => {
                return (
                  <View style={styles.dropdownButtonStyle}>
                    <Text style={styles.dropdownButtonTxtStyle}>
                      {alertType}
                    </Text>
                    <Icon name={isOpened ? 'chevron-up' : 'chevron-down'} style={styles.dropdownButtonArrowStyle} />
                  </View>
                );
              }}
              renderItem={(item, index, isSelected) => {
                return (
                  <View style={{ ...styles.dropdownItemStyle, ...(isSelected && {}) }}>
                    <Text style={styles.dropdownItemTxtStyle}>{item}</Text>
                  </View>
                );
              }}
              showsVerticalScrollIndicator={false}
              dropdownStyle={styles.dropdownMenuStyle}
            />
            <PrimaryButton
              title={"Close"}
              onPress={() => sethomeoverlay(false)}
              style={styles.ClosebtnContainer}
            />
          </View>
        </Modal>}

      {/* Status Bar */}
      <StatusBar barStyle='light-content' backgroundColor={'transparent'} translucent={true} />
      {/* Welcome, Name And LogOut */}
      <TransferWelcomeDashboardComponent
        imageSource={require('@/assets/images/user-profile.jpg')}
        title={Constants.HEADER_TITLE}
        name={''}
        onPress={''}
      // onPressProfile={() => navigation.navigate('EditProfileScreen')}
      />

      {/* List Of Data */}
      <ScrollView style={styles.mainContainer}>
        {/* FlatList */}
        <View style={styles.topContainer}>

          <TouchableOpacity onPress={() => { sethomeoverlay(true) }} style={[styles.dropdownMenuStyle, { width: widthPercentageToDP(92), padding: 12, marginTop: 5, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
            <Text style={{ fontWeight: '500', }}>{alertType}</Text>
            {homeoverlay ?
              <MaterialCommunityIcons name='chevron-up' size={25} />
              :
              <MaterialCommunityIcons name='chevron-down' size={25} />
            }
          </TouchableOpacity>

          {/* <Text style={styles.text01}>Select Date Range</Text> */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginTop: 10 }}>
            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 15 }}>Start Date & Time</Text>
            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 15 }}>End Date & Time</Text>
          </View>
          <View style={styles.feesTotalPaymentContainer}>
            <View style={{ flexDirection: 'row' }}>
              <TouchableOpacity onPress={() => fromDateShow()}><Text style={styles.dateContainer}>{("0" + (fromdate.getMonth() + 1)).slice(-2) + "-" + fromdate.getDate() + "-" + fromdate.getFullYear()}</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => { fromTimeShow() }}><Text style={styles.dateContainer}>{fromtime.getHours() + ":" + fromtime.getMinutes() + ":" + fromtime.getSeconds()}</Text></TouchableOpacity>
            </View>

            <View style={{ flexDirection: 'row',marginLeft:10 }}>
              <TouchableOpacity onPress={() => { toDateShow() }}><Text style={styles.dateContainer}>{("0" + (todate.getMonth() + 1)).slice(-2) + "-" + todate.getDate() + "-" + todate.getFullYear()}</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => { toTimeShow() }}><Text style={styles.dateContainer}>{totime.getHours() + ":" + totime.getMinutes() + ":" + totime.getSeconds()}</Text></TouchableOpacity>
            </View>
          </View>

          <SecondaryButton
            title={"Search"}
            onPress={() => {alerts() }}
            style={styles.btnContainer}
            loading={loading}
          />
        </View>

        {temperaturealertsData.map((alert) => {
          return (
            <View style={{ backgroundColor: ColorSheet.White, padding: 10, marginTop: 10, borderRadius: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Image source={{ uri: alert.BrandLogo }} style={{ width: 50, height: 50 }} />
                <Text style={{ fontWeight: 'bold', fontSize: 18, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>{alert.Brand}</Text>
              </View>
              <View>
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                  <MaterialCommunityIcons name='car-brake-low-pressure' size={25} color={ColorSheet.Error} />
                  <Text style={{ fontWeight: 'bold', fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>{alert.AlertName}</Text>
                </View>
                <Text style={{ fontSize: 13, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Last Occurance: {alert.AlertDateTime}</Text>
                <Text style={{ fontSize: 13, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Total Occurances: {alert.AlertCNT}</Text>
              </View>
            </View>
          )
        })}
      </ScrollView>

    </KeyboardAvoidingView>
  );
};

export default TransactionList;

const listData = [
  {
    id: 1,
    image: require('@/assets/images/Transaction/TransactionProfile.png'),
    name: 'Yara Khalil',
    date: 'Oct 14, 10:24 AM',
    amount: '£15.00',
    type: 'success',
  }
];
