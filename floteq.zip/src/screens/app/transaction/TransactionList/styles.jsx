import { ColorSheet } from '@/utils/ColorSheet';
import { Platform, StyleSheet } from 'react-native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

export const styles = StyleSheet.create({
  feesTotalPaymentContainer: {
    marginVertical: hp(0.3),
    flexDirection: 'row',
    justifyContent: 'space-around',
    borderColor: ColorSheet.Primary,
    // backgroundColor: 'red'
  },
  dateContainer: { backgroundColor: ColorSheet.White, paddingLeft: 15, paddingRight: 15, paddingTop: 5, paddingBottom: 5, marginRight: 2, height: 30, borderRadius: 25, justifyContent: 'center', alignItems: 'center' },
  btnContainer: {
    width: '100%',
    height: Platform.OS == 'ios' ? hp(5.5) : hp(4),
    marginTop: hp(1),
    borderRadius: 15,
    backgroundColor:ColorSheet.White
  },
  dropdownButtonStyle: {
    width: widthPercentageToDP(80),
    height: 50,
    backgroundColor: '#E9ECEF',
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 12,
    marginTop:15
  },
  dropdownButtonTxtStyle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '500',
    color: '#151E26',
  },
  dropdownButtonArrowStyle: {
    fontSize: 28,
  },
  dropdownButtonIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },
  dropdownMenuStyle: {
    backgroundColor: '#E9ECEF',
    borderRadius: 8,
    width: widthPercentageToDP(80),
  },
  dropdownItemStyle: {
    width: '80%',
    flexDirection: 'row',
    paddingHorizontal: 12,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 8,
  },
  homedropdownItemStyle: {
    width: '90%',
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8
  },
  dropdownItemTxtStyle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '500',
    color: '#151E26',
  },
  dropdownItemIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    width: wp(100),
  },
  scrollView:{
    flex:1,
    width: wp(100),
  },
  backgroundImage: {
    position: 'absolute',
    zIndex: -1,
    resizeMode: 'stretch',
    width: wp(100),
    height: Platform.OS == 'ios' ? hp(100) : hp(105),
  },
  mainContainer: {
    width: wp(95),
    alignSelf: 'center',
    marginBottom:100
    // backgroundColor: 'pink',
  },
  topContainer: {
      padding: wp(1.2),
      borderRadius: 20,
      borderColor: ColorSheet.Primary,
      borderWidth: 1,
      marginTop: hp(1),
      height: 'auto',
      justifyContent: 'center',
      backgroundColor: ColorSheet.PrimaryButton,
    },
  flatListContainer: {
    paddingBottom: hp(26),
  },
});
