export const Constants = {
  HEADER_TITLE: 'Floteq USA Alerts',
};
