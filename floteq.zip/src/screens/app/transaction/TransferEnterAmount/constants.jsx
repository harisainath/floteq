export const Constants = {
  HEADER_TITLE: 'Enter Amount',

  EXCHANGE_RATE: 'Exchange Rate',

  SAVING_ACC: 'Sending Amount',
  RECIEVING_AMOUNT: 'Recieving Amount',

  FEE: 'Fee',
  TOTAL_PAYMENT: 'Total Payment',

  SEND: 'Send',
};
