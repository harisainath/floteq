import {
    Alert,
    FlatList,
    Image,
    KeyboardAvoidingView,
    Platform,
    Pressable,
    ScrollView,
    SectionList,
    StatusBar,
    Text,
    View,
} from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import TransferWelcomeDashboardComponent from '@/components/transaction/transferWelcomeDashboard';
import { Constants } from './constants';
import { styles } from './styles';
import { styles as currencyConvertor } from '../../../../src/components/transaction/currency_convater/styles';
import DashedBorder from '@/assets/svg/transaction/dashedBorder.svg';
import SecondaryButton from '@/components/buttons/secondaryButton';
import CurrencyCoveter from '@/components/transaction/currency_convater';

import ImageSlider from '@/components/image_slider';
import { StackActions, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withTiming,
    withSpring,
} from 'react-native-reanimated';
import AnimatedTextInput from '@/components/input/AnimatedTextInput';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Rotate from '@/assets/svg/transaction/Rotate.svg';
import postRequest from '@/components/NetworkRequest/postRequest';
import { DefaultConstants } from '@/utils/Constants';
import { ErrorFlash } from '@/utils/flashMessage';
import {
    heightPercentageToDP as hp,
    widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import Spinner from 'react-native-loading-spinner-overlay';
import DateTimePicker from '@react-native-community/datetimepicker';
import { ColorSheet } from '@/utils/ColorSheet';
import Speedometer from 'react-native-speedometer-chart';
import BeneficiarySearchListData from '@/components/transaction/beneficiarySearchListData';
import { AntDesign, FontAwesome5, Foundation, MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';

const DetailsScreen = ({ navigation, route }) => {
    // const navigation = useNavigation();
    const { pourscore, item, temperaturealerts,pressurealerts,afterhoursalerts,cleaningdetectedalerts } = route.params
    
    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS == 'ios' ? 'padding' : 'height'}
        >
            {/* Status Bar */}
            <StatusBar barStyle='light-content' backgroundColor={'transparent'} translucent={true} />


            <View style={[styles.root]}>
                {/* Image */}
                <View style={styles.imageNameContainer}>
                    <View style={styles.NameContainer}>
                        {/* Welcome Title */}
                        <TouchableOpacity onPress={() => navigation.goBack()}><MaterialCommunityIcons name='keyboard-backspace' size={30} /></TouchableOpacity>
                        <Text style={styles.welcomeText}>{pourscore.Brand} </Text>
                        <Image source={{ uri: item.BrandLogo }} style={{ width: 60, height: 60, marginRight: 15 }} resizeMode='contain' />
                    </View>
                    
                </View>

                {/* Icon */}

            </View>


            <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
                {/* mainContainer */}
                <View style={styles.mainContainer}>
                    <View style={currencyConvertor.topContainer}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }}>
                            <View style={{ width: wp(33) }}>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 14 }}>
                                    PourScore
                                </Text>
                            </View>
                            <View style={{}}>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Sales: ${pourscore["POS NET"]}</Text>
                                <Speedometer
                                    value={pourscore["PourScore - $"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#fdb904"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: 'red' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5  }}>
                                    <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                    <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                            <View>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 13,marginBottom:5  }}>Ounces: {pourscore["POS OZ"]}</Text>
                                <Speedometer
                                    value={pourscore["PourScore"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#34cb58"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: 'red' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5  }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                        </View>
                    </View>


                    <View style={currencyConvertor.topContainer}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }}>
                            <View style={{ width: wp(33) }}>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 14 }}>
                                    Temperature
                                </Text>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11 }}>(F)</Text>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Min</Text>
                                <Speedometer
                                    value={item["MinTemp"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#f23852"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: 'red' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Avg</Text>
                                <Speedometer
                                    value={item["AvgTemp"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#fdb904"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: 'red' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Max</Text>
                                <Speedometer
                                    value={item["MaxTemp"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#34cb58"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: 'red' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                        </View>
                    </View>


                    <View style={currencyConvertor.topContainer}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }}>
                            <View style={{ width: wp(33) }}>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 14 }}>
                                    Pressure
                                </Text>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11 }}>(psi)</Text>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Min</Text>
                                <Speedometer
                                    value={item["MinPres"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#087cff"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: '#087cff' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Avg</Text>
                                <Speedometer
                                    value={item["AvgPres"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#087cff"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: '#087cff' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Max</Text>
                                <Speedometer
                                    value={item["MaxPres"]}
                                    totalValue={100}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#087cff"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: '#087cff' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>100</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                    <View style={currencyConvertor.topContainer}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }}>
                            <View style={{ width: wp(33) }}>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 14 }}>
                                    Total dissolved solids
                                </Text>
                                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11 }}>(tds)</Text>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Min</Text>
                                <Speedometer
                                    value={parseInt(item["MinTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, ""))}
                                    totalValue={parseInt(parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "")) * 25 / 100)}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#087cff"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: '#087cff' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                    <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                    <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>{parseInt(parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "")) * 25 / 100)}</Text>
                                </View>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Avg</Text>
                                <Speedometer
                                    value={parseInt(item["AvgTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, ""))}
                                    totalValue={parseInt(parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "")) * 25 / 100)}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#087cff"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: '#087cff' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                    <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                    <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>{parseInt(parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "")) * 25 / 100)}</Text>
                                </View>
                            </View>
                            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 11,marginBottom:5 }}>Max</Text>
                                <Speedometer
                                    value={parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, ""))}
                                    totalValue={parseInt(parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "")) * 25 / 100)}
                                    size={60}
                                    outerColor="#d3d3d3"
                                    internalColor="#087cff"
                                    showText

                                    labelStyle={{ color: ColorSheet.White }}
                                    labelFormatter={number => `${number}`}
                                    showPercent
                                    percentStyle={{ color: '#087cff' }}
                                    outerCircleStyle={{ width: 60 }}
                                    innerCircleStyle={{ width: 50, height: 26, }}
                                />
                                <View style={{ flexDirection: 'row',marginTop:5 }}>
                                    <Text style={{ color: ColorSheet.White,fontSize:8,fontWeight:'bold' }}>0</Text>
                                    <Text style={{ color: ColorSheet.White, marginLeft: 42,fontSize:8,fontWeight:'bold' }}>{parseInt(parseInt(item["MaxTDS"].replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, "")) * 25 / 100)}</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                    <View style={{ backgroundColor: ColorSheet.White, padding: 10, marginTop: 10, borderRadius: 10 }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Foundation name='alert' size={20} color={ColorSheet.Error} />
                            <Text style={{ fontWeight: 'bold', fontSize: 18, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>Alerts</Text>
                        </View>
                        {temperaturealerts &&
                        <View>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                                <MaterialCommunityIcons name='car-brake-low-pressure' size={25} color={ColorSheet.Error} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>{temperaturealerts.AlertName}</Text>
                            </View>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Last Occurance: {temperaturealerts.AlertDateTime}</Text>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Total Occurances: {temperaturealerts.AlertCNT}</Text>
                        </View> }

                        {pressurealerts &&
                        <View style={{ marginTop: 10 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                                <FontAwesome5 name='temperature-high' size={25} color={ColorSheet.Error} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>{pressurealerts.AlertName}</Text>
                            </View>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Last Occurance: {pressurealerts.AlertDateTime}</Text>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Total Occurances: {pressurealerts.AlertCNT}</Text>
                        </View> }

                        {afterhoursalerts &&
                        <View style={{ marginTop: 10 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                                <FontAwesome5 name='temperature-high' size={25} color={ColorSheet.Error} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>{afterhoursalerts.AlertName}</Text>
                            </View>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Last Occurance: {afterhoursalerts.AlertDateTime}</Text>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Total Occurances: {afterhoursalerts.AlertCNT}</Text>
                        </View>}

                        {cleaningdetectedalerts &&
                        <View style={{ marginTop: 10 }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                                <FontAwesome5 name='temperature-high' size={25} color={ColorSheet.Error} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: ColorSheet.PrimaryButton, marginLeft: 10 }}>{cleaningdetectedalerts.AlertName}</Text>
                            </View>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Last Occurance: {cleaningdetectedalerts.AlertDateTime}</Text>
                            <Text style={{ fontSize: 15, color: ColorSheet.PrimaryButton, marginLeft: 35 }}>Total Occurances: {cleaningdetectedalerts.AlertCNT}</Text>
                        </View>}
                    </View>

                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
};

export default DetailsScreen;
