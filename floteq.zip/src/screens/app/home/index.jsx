import {
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  SectionList,
  StatusBar,
  Text,
  View,
} from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import TransferWelcomeDashboardComponent from '@/components/transaction/transferWelcomeDashboard';
import { Constants } from './constants';
import { styles } from './styles';
import { styles as currencyConvertor } from '../../../../src/components/transaction/currency_convater/styles';
import DashedBorder from '@/assets/svg/transaction/dashedBorder.svg';
import SecondaryButton from '@/components/buttons/secondaryButton';
import CurrencyCoveter from '@/components/transaction/currency_convater';

import ImageSlider from '@/components/image_slider';
import { StackActions, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
} from 'react-native-reanimated';
import AnimatedTextInput from '@/components/input/AnimatedTextInput';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Rotate from '@/assets/svg/transaction/Rotate.svg';
import postRequest from '@/components/NetworkRequest/postRequest';
import { DefaultConstants } from '@/utils/Constants';
import { ErrorFlash } from '@/utils/flashMessage';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import Spinner from 'react-native-loading-spinner-overlay';
import DateTimePicker, { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { ColorSheet } from '@/utils/ColorSheet';
import Speedometer from 'react-native-speedometer-chart';
import BeneficiarySearchListData from '@/components/transaction/beneficiarySearchListData';
import { AntDesign, MaterialCommunityIcons } from '@expo/vector-icons';
import axios from 'axios';
import Modal from 'react-native-modal';
import SelectDropdown from 'react-native-select-dropdown'
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import PrimaryButton from '@/components/buttons/primaryButton';

const HomeScreen = () => {
  const navigation = useNavigation();

  useEffect(() => {
    getLoactions();
    setDates()
  }, [])

  const [locations, setLocations] = useState([]);
  const [devices, setDevices] = useState([]);

  const [overlay, setoverlay] = useState(false);
  const [homeoverlay, sethomeoverlay] = useState(false);

  const [fromdate, setFromDate] = useState(new Date());
  const [fromtime, setfromtime] = useState(new Date());
  const [todate, setToDate] = useState(new Date());
  const [totime, settotime] = useState(new Date());

  const [AccountID, setAccountID] = useState()
  const [LocationID, setLocationID] = useState()
  const [LocationName, setLocationName] = useState('Select your Location')

  const [DevicesID, setDevicesID] = useState()
  const [Name, setName] = useState('Select your Device')
  const [Serial, setSerial] = useState()

  const [pourScoreData, setPourScoreData] = useState([])
  const [pourScorepercent, setPourScorepercent] = useState()
  const [pourScore, setPourScore] = useState()

  const [homeData, setHomeData] = useState([])
  const [temperaturealertsData, settemperaturealertsData] = useState([])
  const [pressurealertsData, setpressurealertsData] = useState([])
  const [afterhoursalertsData, setafterhoursalertsData] = useState([])
  const [cleaningdetectedalertsData, setcleaningdetectedalertsData] = useState([])

  const [loading, setLoading] = useState(false)
  const setDates = async () => {
    var currentdate = new Date();
    if (currentdate.getHours() >= 6) {
      setFromDate(new Date())
      setToDate(new Date(currentdate.getTime() + 86400000))
      setfromtime(new Date(currentdate.setHours(6,0,0)))
      settotime(new Date(new Date(currentdate.getTime() + 86400000).setHours(6,0,0)))
    }
    else {
      setFromDate(new Date(currentdate.getTime() - 86400000))
      setToDate(new Date())
      setfromtime(new Date(new Date(currentdate.getTime() + 86400000).setHours(6,0,0)))
      settotime(new Date(currentdate.setHours(6,0,0)))
    }
  }
  const getLoactions = async () => {
    setLoading(true)
    const UserID = await AsyncStorage.getItem('UserID');
    const api_token = await AsyncStorage.getItem('api_token');
    await axios.get(DefaultConstants.BASE_URL + 'api/get-user-locations/' + UserID, {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
      }
    }).then(resp => {
      setLocations(resp.data)
      setAccountID(resp.data[0].AccountID)
      setLocationID(resp.data[0].LocationID)
      setLocationName(resp.data[0].LocationName)
      getDevices(resp.data[0].LocationID)
      alerts()
      setAsyncdata("locationId", JSON.stringify(resp.data[0].LocationID))
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })
  }
  const alerts = async () => {
    setLoading(true)
    const api_token = await AsyncStorage.getItem('api_token');
    console.log(DefaultConstants.BASE_URL + 'api/alert-center-data?alertType=1&fromdate=' + fromdate.getFullYear() + "-" + ("0" + (fromdate.getMonth() + 1)).slice(-2) + "-" + fromdate.getDate() + "T" + fromtime.getHours() + ":" + fromtime.getMinutes() + ":" + fromtime.getSeconds()+'&todate='+ todate.getFullYear() + "-" + ("0" + (todate.getMonth() + 1)).slice(-2) + "-" + todate.getDate() + "T" + totime.getHours() + ":" + totime.getMinutes() + ":" + totime.getSeconds()+"&page=1");
    
    await axios.get("https://devweb01.flotequsa.com/api/alert-center-data?alertType=1&fromdate=2025-03-12T06%3A00&todate=2025-03-13T06%3A00&page=1", {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
        "Accept":"application/json"
      }
    }).then(resp => {
      console.log("temp data"+JSON.stringify(resp.data));
      settemperaturealertsData(resp.data.data)
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })

    await axios.get("https://devweb01.flotequsa.com/api/alert-center-data?alertType=2&fromdate=2025-03-12T06%3A00&todate=2025-03-13T06%3A00&page=1", {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
        "Accept":"application/json"
      }
    }).then(resp => {
      console.log("press data"+JSON.stringify(resp.data));
      setpressurealertsData(resp.data.data)
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })
    console.log(api_token);
    
    await axios.get("https://devweb01.flotequsa.com/api/alert-center-data?alertType=3&fromdate=2025-03-12T06%3A00&todate=2025-03-13T06%3A00&page=1", {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
        "Accept":"application/json"
      }
    }).then(resp => {
      console.log("after data"+JSON.stringify(resp.data));
      setafterhoursalertsData(resp.data.data)
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })


    await axios.get("https://devweb01.flotequsa.com/api/alert-center-data?alertType=4&fromdate=2025-03-12T06%3A00&todate=2025-03-13T06%3A00&page=1", {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
        "Accept":"application/json"
      }
    }).then(resp => {
      console.log("cleaning data"+JSON.stringify(resp.data));
      setcleaningdetectedalertsData(resp.data.data)
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })
  }
  const getDevices = async (locationId) => {
    setLoading(true)
    const api_token = await AsyncStorage.getItem('api_token');
    await axios.get(DefaultConstants.BASE_URL + 'api/load/devices/' + locationId, {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
      }
    }).then(resp => {
      setDevices(resp.data)
      setDevicesID(resp.data[0].DevicesID)
      setName(resp.data[0].Name)
      setSerial(resp.data[0].Serial)
      getLineData(resp.data[0].DevicesID)
    }).catch(err => {
      console.log(err.response.data);
      ErrorFlash(err.response.data);
      setLoading(false)
    })
  }

  const getLineData = async (deviceId) => {
    setLoading(true)
    const api_token = await AsyncStorage.getItem('api_token');
    var url = (DefaultConstants.BASE_URL + 'api/load/line/data/' + deviceId + "/" + fromdate.getFullYear() + "-" + ("0" + (fromdate.getMonth() + 1)).slice(-2) + "-" + fromdate.getDate() + "T" + fromtime.getHours() + ":" + fromtime.getMinutes() + ":" + fromtime.getSeconds() + "/" + todate.getFullYear() + "-" + ("0" + (todate.getMonth() + 1)).slice(-2) + "-" + todate.getDate() + "T" + totime.getHours() + ":" + totime.getMinutes() + ":" + totime.getSeconds()) + "/1";
    // url = "https://devweb01.flotequsa.com/api/load/line/data/435020109/2025-03-01T13:24:46/2025-03-10T13:24:46/1";
    
    await axios.get(url, {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
      }
    }).then(resp => {
      setHomeData(resp.data.result)
      getPourScoreData(deviceId)
    }).catch(err => {
      console.log(err.response);
      ErrorFlash(err.response.data);
      setLoading(false)
    })
  }

  const getPourScoreData = async (deviceId) => {
    const api_token = await AsyncStorage.getItem('api_token');
    var url = (DefaultConstants.BASE_URL + 'api/pour-score-detail-data/' + deviceId + "/" + fromdate.getFullYear() + "-" + ("0" + (fromdate.getMonth() + 1)).slice(-2) + "-" + fromdate.getDate() + "T" + fromtime.getHours() + ":" + fromtime.getMinutes() + ":" + fromtime.getSeconds() + "/" + todate.getFullYear() + "-" + ("0" + (todate.getMonth() + 1)).slice(-2) + "-" + todate.getDate() + "T" + totime.getHours() + ":" + totime.getMinutes() + ":" + totime.getSeconds());
    // url = "https://devweb01.flotequsa.com/api/pour-score-detail-data/435020109/2025-03-01T13:24:46/2025-03-10T13:24:46";
    await axios.get(url, {
      headers: {
        "Authorization": 'Bearer ' + api_token,
        "X-Requested-With": 'AppUser',
      }
    }).then(resp => {
      setPourScoreData(resp.data.result)
      setPourScore(resp.data.total["POS NET"])
      setPourScorepercent(resp.data.total["PourScore - $"])
      setLoading(false)
    }).catch(err => {
      console.log(err.response);
      // ErrorFlash(err.response.data);
      setLoading(false)
    })
  }

  const setAsyncdata = async (key, value) => {
    await AsyncStorage.setItem(key, value);
  }
  const selectLocation = async () => {
    setoverlay(!overlay);
  }
  const onChangeFromdate = (event, selectedDate) => {
    const currentDate = selectedDate;
    setFromDate(currentDate)
  };
  const onChangeFromTime = (event, selectedDate) => {
    const currentDate = selectedDate;
    setfromtime(currentDate)
  };

  const onChangeTodate = (event, selectedDate) => {
    const currentDate = selectedDate;
    setToDate(currentDate)
  };
  const onChangeTotime = (event, selectedDate) => {
    const currentDate = selectedDate;
    settotime(currentDate)
  };

  const fromDateShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeFromdate,
      is24Hour: true,
      mode: 'date'
    });
  }
  const fromTimeShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeFromTime,
      is24Hour: true,
      mode: 'time'
    });
  }

  const toDateShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeTodate,
      is24Hour: true,
      mode: 'date'
    });
  }
  const toTimeShow = async () => {
    DateTimePickerAndroid.open({
      value: fromdate,
      onChange: onChangeTotime,
      is24Hour: true,
      mode: 'time'
    });
  }
  const navigateToDetailsScreen = async (item) => {
    var pourscore = "";
    var temperaturealerts = "";
    var pressurealerts = "";
    var afterhoursalerts = "";
    var cleaningdetectedalerts = "";
    for (let i = 0; i < pourScoreData.length; i++) {
      if (pourScoreData[i].BeerBrandsID == item.BeerBrandsID) {
        pourscore = pourScoreData[i]
      }
    }

    for (let j = 0; j < temperaturealertsData.length; j++) {
      if (temperaturealertsData[j].BeerBrandsID == item.BeerBrandsID) {
        temperaturealerts = temperaturealertsData[j]
      }
    }

    for (let k = 0; k < pressurealertsData.length; k++) {
      if (pressurealertsData[k].BeerBrandsID == item.BeerBrandsID) {
        pressurealerts = pressurealertsData[k]
      }
    }

    for (let l = 0; l < afterhoursalertsData.length; l++) {
      if (afterhoursalertsData[l].BeerBrandsID == item.BeerBrandsID) {
        afterhoursalerts = afterhoursalertsData[l]
      }
    }

    for (let m = 0; m < cleaningdetectedalertsData.length; m++) {
      if (cleaningdetectedalertsData[m].BeerBrandsID == item.BeerBrandsID) {
        cleaningdetectedalerts = cleaningdetectedalertsData[m]
      }
    }

    navigation.navigate('DetailsScreen', { pourscore: pourscore, item: item, temperaturealerts: temperaturealerts,pressurealerts:pressurealerts,afterhoursalerts:afterhoursalerts,cleaningdetectedalerts:cleaningdetectedalerts })
  }
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS == 'ios' ? 'padding' : 'height'}
    >
      {loading &&
        <Spinner
          visible={loading}
          textContent={'Loading...'}
          textStyle={{ color: '#FFF' }}
        />
      }
      {!loading &&
        <Modal isVisible={overlay}>
          <View style={{ flex: 0.15, backgroundColor: ColorSheet.White, padding: 10, justifyContent: 'center', alignItems: 'center' }}>
            <SelectDropdown
              data={locations}
              onSelect={(selectedItem, index) => {
                setAccountID(selectedItem.AccountID)
                setLocationID(selectedItem.LocationID)
                setLocationName(selectedItem.LocationName)
                getDevices(selectedItem.LocationID)
                setoverlay(false)
              }}
              renderButton={(selectedItem, isOpened) => {
                return (
                  <View style={styles.dropdownButtonStyle}>
                    <Text style={styles.dropdownButtonTxtStyle}>
                      {LocationName}
                    </Text>
                    <Icon name={isOpened ? 'chevron-up' : 'chevron-down'} style={styles.dropdownButtonArrowStyle} />
                  </View>
                );
              }}
              renderItem={(item, index, isSelected) => {
                return (
                  <View style={{ ...styles.dropdownItemStyle, ...(isSelected && {}) }}>
                    <Text style={styles.dropdownItemTxtStyle}>{item.LocationName}</Text>
                  </View>
                );
              }}
              showsVerticalScrollIndicator={false}
              dropdownStyle={styles.dropdownMenuStyle}
            />
            <PrimaryButton
              title={Constants.CLOSE}
              onPress={() => setoverlay(false)}
              style={styles.ClosebtnContainer}
            />
          </View>
        </Modal>}
      {!loading &&
        <Modal isVisible={homeoverlay}>
          <View style={{ flex: 0.15, backgroundColor: ColorSheet.White, padding: 10, justifyContent: 'center', alignItems: 'center' }}>
          <SelectDropdown
            data={devices}
            onSelect={(selectedItem, index) => {
              setDevicesID(selectedItem.DevicesID)
              setName(selectedItem.Name)
              setSerial(selectedItem.Serial)
            }}
            renderButton={(selectedItem, isOpened) => {
              return (
                <View style={styles.dropdownButtonStyle}>
                  <Text style={styles.dropdownButtonTxtStyle}>
                    {Name}
                  </Text>
                  <Icon name={isOpened ? 'chevron-up' : 'chevron-down'} style={styles.dropdownButtonArrowStyle} />
                </View>
              );
            }}
            renderItem={(item, index, isSelected) => {
              return (
                <View style={{ ...styles.dropdownItemStyle, ...(isSelected && {}) }}>
                  <Text style={styles.dropdownItemTxtStyle}>{item.Name}</Text>
                </View>
              );
            }}
            showsVerticalScrollIndicator={false}
            dropdownStyle={styles.dropdownMenuStyle}
          />
          <PrimaryButton
              title={Constants.CLOSE}
              onPress={() => sethomeoverlay(false)}
              style={styles.ClosebtnContainer}
            />
        </View>
        </Modal>}
      {/* Status Bar */}
      <StatusBar barStyle='light-content' backgroundColor={'transparent'} translucent={true} />

      {/* Image */}
      {/* <Image
        style={styles.backgroundImage}
        source={require('@/assets/images/Transaction/BG.png')}
      /> */}

      {/* Welcome, Name And LogOut */}
      <TransferWelcomeDashboardComponent
        imageSource={require('@/assets/images/user-profile.jpg')}
        title={Constants.WELCOME_BACK}
        name={''}
        onPress={selectLocation}
      // onPressProfile={() => navigation.navigate('EditProfileScreen')}
      />
      {!loading &&
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* mainContainer */}
          <View style={styles.mainContainer}>
            <View style={currencyConvertor.topContainer}>

              <TouchableOpacity onPress={() => { sethomeoverlay(true) }} style={[styles.dropdownMenuStyle, { width: wp(92), padding: 12, marginTop: 5, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
                <Text style={{ fontWeight: '500', }}>{Name}</Text>
                {homeoverlay ?
                  <MaterialCommunityIcons name='chevron-up' size={25} />
                  :
                  <MaterialCommunityIcons name='chevron-down' size={25} />
                }
              </TouchableOpacity>

              {/* <Text style={styles.text01}>Select Date Range</Text> */}
              <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginTop: 10 }}>
                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 15 }}>Start Date & Time</Text>
                <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 15 }}>End Date & Time</Text>
              </View>
              <View style={styles.feesTotalPaymentContainer}>
                <View style={{ flexDirection: 'row' }}>
                  <TouchableOpacity onPress={() => fromDateShow()}><Text style={styles.dateContainer}>{("0" + (fromdate.getMonth() + 1)).slice(-2) + "-" + fromdate.getDate() + "-" + fromdate.getFullYear()}</Text></TouchableOpacity>
                  <TouchableOpacity onPress={() => { fromTimeShow() }}><Text style={styles.dateContainer}>{fromtime.getHours() + ":" + fromtime.getMinutes() + ":" + fromtime.getSeconds()}</Text></TouchableOpacity>
                </View>

                <View style={{ flexDirection: 'row',marginLeft:10 }}>
                  <TouchableOpacity onPress={() => { toDateShow() }}><Text style={styles.dateContainer}>{("0" + (todate.getMonth() + 1)).slice(-2) + "-" + todate.getDate() + "-" + todate.getFullYear()}</Text></TouchableOpacity>
                  <TouchableOpacity onPress={() => { toTimeShow() }}><Text style={styles.dateContainer}>{totime.getHours() + ":" + totime.getMinutes() + ":" + totime.getSeconds()}</Text></TouchableOpacity>
                </View>
              </View>
              <SecondaryButton
                title={Constants.SEARCH}
                onPress={() => getLineData(DevicesID)}
                style={styles.btnContainer}
                loading={loading}
              />
            </View>

            <View style={currencyConvertor.topContainer}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }}>
                <View>
                  <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 20 }}>
                    Bar PourScore
                  </Text>
                  <Text style={{ color: ColorSheet.White, fontWeight: 'bold', fontSize: 16 }}>Sales: ${pourScore}</Text>
                </View>
                <View>
                  <Speedometer
                    value={pourScorepercent}
                    totalValue={100}
                    size={70}
                    outerColor="#d3d3d3"
                    internalColor={pourScorepercent < 30 ? "#ff0000" : pourScorepercent >= 30 && pourScorepercent <= 50 ? "#ff7708" : "#57e841"}
                    showText
                    labelStyle={{ color: ColorSheet.White }}
                    labelFormatter={number => `${number}`}
                    showPercent
                    percentStyle={{ color: 'red' }}
                    innerCircleStyle={{ width: 59, height: 29, }}
                  />
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={{ color: ColorSheet.White,fontSize: 11 }}>0</Text>
                    <Text style={{ color: ColorSheet.White, marginLeft: 40,fontSize: 11 }}>100</Text>
                  </View>
                </View>
              </View>
            </View>


            <FlatList
              data={homeData}
              keyExtractor={(item) => item.Line.toString()}
              renderItem={({ item, index }) => {
                // console.log('Beneficiary:', item.img);
                return (
                  <View key={index} style={{ width: "100%", marginBottom: hp(1) }}>
                    <TouchableOpacity onPress={() => { navigateToDetailsScreen(item) }} style={styles.itemsContainer}>
                      <View style={styles.placeholderImageStyle}>
                        <Image style={styles.iconImageStyle} source={{ uri: item.BrandLogo }} />
                      </View>

                      <View style={styles.txtRowContainer}>
                        {/* Name */}
                        <Text style={styles.nameTxt}> {item.Brand} </Text>

                        {/* Id  */}
                        <Text style={styles.numberTxt}>
                          {' '}
                          {item.LastPourTime}
                        </Text>
                      </View>
                      <View style={{ position: 'absolute', right: 20 }}>
                        <AntDesign name='caretright' size={16} />
                      </View>
                    </TouchableOpacity>
                  </View>
                );
              }}
            />
          </View>
        </ScrollView>}
    </KeyboardAvoidingView>
  );
};

export default HomeScreen;
