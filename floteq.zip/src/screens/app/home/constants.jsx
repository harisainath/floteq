export const Constants = {
  WELCOME_BACK: 'Floteq USA Dashboard',
  EXCHANGE_RATE: 'Exchange Rate',

  SAVING_ACC: 'Sending Amount',
  RECIEVING_AMOUNT: 'Recieving Amount',

  FEE: 'Fee',
  TOTAL_PAYMENT: 'Total Payment',

  SEARCH: 'Search',
  CLOSE: 'Close',
  ADD: 'Add',
  SENDING_AMOUNt_ERROR: 'Enter Sending Amount'
};
