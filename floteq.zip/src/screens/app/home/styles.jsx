import { ColorSheet } from '@/utils/ColorSheet';
import { Platform, StyleSheet } from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

export const styles = StyleSheet.create({
  root: {
    width: '93%',
    marginTop: Platform.OS == 'android' ? hp(7) : hp(9),
    flexDirection: 'row',
    // backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  imageNameContainer: {
   justifyContent:'center',
   alignItems:'center'
    // backgroundColor: 'green'
  },
  NameContainer: {
    alignItems:'center',
    width: wp(95),
    flexDirection:'row',
    justifyContent:'space-between'
  },
  welcomeText: {
    fontSize: RFValue(18),
    fontWeight: '700',
    color: ColorSheet.PrimaryButton,
    marginLeft: wp(3),
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  dateContainer: { backgroundColor: ColorSheet.White, paddingLeft: 15, paddingRight: 15, paddingTop: 5, paddingBottom: 5, marginRight: 2, height: 30, borderRadius: 25, justifyContent: 'center', alignItems: 'center' },
  itemsContainer:{
    width: '100%',
    padding: hp(1),
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: ColorSheet.Secondary,
  },
  placeholderImageStyle: {
    width: wp(12),
    height: wp(12),
    borderRadius: wp(6),
    backgroundColor: '#D3D3D3', // Replace with your desired background color
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: {
    fontSize: RFValue(12),
    color: ColorSheet.Text0,
    fontWeight: 'bold',
  },
  iconImageStyle: {
    width: wp(12),
    height: wp(12),
    borderRadius: wp(6),
    resizeMode: 'contain',
  },
  txtRowContainer: {
    marginLeft: hp(1),
  },
  nameTxt: {
    fontSize: RFValue(12),
    color: ColorSheet.Text0,
    fontWeight: 'bold',
  },
  numberTxt: {
    paddingTop: hp(0.5),
    fontSize: RFValue(12),
    color: ColorSheet.CheckBox,
    fontWeight: '500',
  },
  container: {
    flex: 1,
    alignItems: 'center',
    width: wp(100),
  },
  backgroundImage: {
    position: 'absolute',
    zIndex: -1,
    resizeMode: 'stretch',
    width: wp(100),
    height: hp(70),
  },
  mainContainer: {
    width: wp(95),
    paddingBottom: hp(2),

    alignSelf: 'center',
    // backgroundColor: 'pink',
    marginBottom: hp(15),
  },
  scrollView: {},
  exchangeContainer: {
    width: '100%',
    height: 40,
    // padding: hp(1),
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: ColorSheet.PrimaryButton,
    borderRadius: hp(1),
    marginBottom: hp(1)
  },
  exchangeText: {
    fontSize: RFValue(14),
    fontWeight: '700',
    color: ColorSheet.PrimaryButtonTxt,
  },
  exchangeAmount: {
    fontSize: RFValue(14),
    fontWeight: '700',
    color: ColorSheet.Secondary,
  },
  dashedBorder: {
    marginTop: hp(0),
    alignSelf: 'center',
    // backgroundColor: 'red'
  },
  feesTotalPaymentContainer: {
    marginVertical: hp(0.3),
    flexDirection: 'row',
    justifyContent: 'space-around',
    borderColor: ColorSheet.Primary,
    // backgroundColor: 'red'
  },

  text01: {
    fontSize: RFValue(18),
    fontWeight: '600',
    color: ColorSheet.White,
    width: wp(100),
  },
  textAmount: {
    fontSize: RFValue(14),
    fontWeight: '500',
    color: ColorSheet.PrimaryButton,
  },
  btnContainer: {
    width: '100%',
    height: Platform.OS == 'ios' ? hp(5.5) : hp(4),
    marginTop: hp(1),
    borderRadius: 15,
    backgroundColor:ColorSheet.White
  },
  ClosebtnContainer: {
    width: '95%',
    height: Platform.OS == 'ios' ? hp(6.5) : hp(5),
    marginTop: hp(1),
    borderRadius: 15,
    backgroundColor:ColorSheet.Primary
  },
  imageStyle: {
    width: wp(90),
    height: hp(25),
    marginTop: hp(2),
    resizeMode: 'contain',
    alignSelf: 'center',
  },
  dropdownButtonStyle: {
    width: widthPercentageToDP(80),
    height: 50,
    backgroundColor: '#E9ECEF',
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 12,
    marginTop:15
  },
  dropdownButtonTxtStyle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '500',
    color: '#151E26',
  },
  dropdownButtonArrowStyle: {
    fontSize: 28,
  },
  dropdownButtonIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },
  dropdownMenuStyle: {
    backgroundColor: '#E9ECEF',
    borderRadius: 8,
    width: widthPercentageToDP(80),
  },
  dropdownItemStyle: {
    width: '80%',
    flexDirection: 'row',
    paddingHorizontal: 12,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 8,
  },
  homedropdownItemStyle: {
    width: '90%',
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8
  },
  dropdownItemTxtStyle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '500',
    color: '#151E26',
  },
  dropdownItemIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },
});
